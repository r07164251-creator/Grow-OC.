package com.growoc.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

data class Palette(
    val id: String, val name: String, val dark: Boolean,
    val bg: Color, val glass: Color, val text: Color, val accent: Color
)

val Themes = listOf(
    Palette("liquid_light", "Liquid Light", false, Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFF1C1C1E), Color(0xFF0A84FF)),
    Palette("liquid_dark", "Liquid Dark", true, Color(0xFF0B0B0D), Color(0xFF2C2C2E), Color(0xFFF2F2F7), Color(0xFF0A84FF)),
    Palette("pure_white", "Pure White", false, Color(0xFFFFFFFF), Color(0xFFF5F5F7), Color(0xFF111111), Color(0xFF8E8E93)),
    Palette("graphite", "Graphite", true, Color(0xFF1C1C1E), Color(0xFF3A3A3C), Color(0xFFE5E5EA), Color(0xFF64D2FF)),
    Palette("minimal_black", "Minimal Black", true, Color(0xFF000000), Color(0xFF1C1C1E), Color(0xFFFFFFFF), Color(0xFFFFFFFF)),
    Palette("liquid_blue", "Liquid Blue", false, Color(0xFFE8F1FF), Color(0xFFFFFFFF), Color(0xFF0B1B33), Color(0xFF0A84FF)),
    Palette("soft_silver", "Soft Silver", false, Color(0xFFE5E5EA), Color(0xFFF2F2F7), Color(0xFF2C2C2E), Color(0xFF8E8E93)),
)

val LocalPalette = staticCompositionLocalOf { Themes[0] }

@Composable
fun GrowTheme(p: Palette, content: @Composable () -> Unit) {
    val scheme = if (p.dark)
        darkColorScheme(primary = p.accent, background = p.bg, surface = p.glass, onSurface = p.text, onBackground = p.text)
    else
        lightColorScheme(primary = p.accent, background = p.bg, surface = p.glass, onSurface = p.text, onBackground = p.text)
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Translucent surface, soft shadow, light-catching hairline edge. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp), alpha: Float = 0.55f): Modifier {
    val p = LocalPalette.current
    return this
        .shadow(10.dp, shape, clip = false, ambientColor = Color.Black.copy(0.12f), spotColor = Color.Black.copy(0.12f))
        .clip(shape)
        .background(p.glass.copy(alpha = alpha))
        .border(0.8.dp, Brush.verticalGradient(listOf(Color.White.copy(0.55f), Color.White.copy(0.06f))), shape)
}
