package com.growoc.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.data.*
import kotlinx.coroutines.launch

class Actions(
    val open: (AppItem) -> Unit,
    val dock: (AppItem) -> Unit,
    val hide: (AppItem) -> Unit,
    val info: (AppItem) -> Unit
)

@Composable
fun Home(pr: Preferences) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    LaunchedEffect(Unit) { apps = ctx.loadApps() }

    val columns = pr[K.COLUMNS] ?: 4
    val hidden = pr[K.HIDDEN] ?: emptySet()
    val dock = (pr[K.DOCK] ?: "").split(",").filter { it.isNotBlank() }
    var query by remember { mutableStateOf("") }
    var island by remember { mutableStateOf<IslandTab?>(null) }
    val visible = apps.filter { it.pkg !in hidden && (query.isBlank() || it.label.contains(query, true)) }

    BackHandler(island != null || query.isNotEmpty()) {
        if (island != null) island = null else query = ""
    }

    val actions = Actions(
        open = { runCatching { ctx.startActivity(it.intent) } },
        dock = { app ->
            scope.launch {
                val next = if (app.pkg in dock) dock - app.pkg else (dock + app.pkg).takeLast(5)
                ctx.save(K.DOCK, next.joinToString(","))
            }
        },
        hide = { app -> scope.launch { ctx.save(K.HIDDEN, hidden + app.pkg) } },
        info = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${it.pkg}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    )

    Box(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 12.dp)) {
        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(72.dp)) // room for the Island pill
            SearchBar(query) { query = it }
            Box(Modifier.weight(1f)) { Pages(visible, columns, dock, actions) }
            Dock(dock.mapNotNull { d -> apps.firstOrNull { it.pkg == d } }, actions)
        }
        GrowIsland(island, { t -> island = if (island == t) null else t }, pr, Modifier.align(Alignment.TopCenter))
    }
}

@Composable
private fun SearchBar(q: String, onQ: (String) -> Unit) {
    val p = LocalPalette.current
    BasicTextField(
        value = q, onValueChange = onQ, singleLine = true,
        textStyle = TextStyle(color = p.text, fontSize = 16.sp),
        cursorBrush = SolidColor(p.accent),
        modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp), 0.5f)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        decorationBox = { inner ->
            Box {
                if (q.isEmpty()) Text("Search apps", color = p.text.copy(0.4f), fontSize = 16.sp)
                inner()
            }
        }
    )
}

@Composable
private fun Pages(apps: List<AppItem>, columns: Int, docked: List<String>, a: Actions) {
    val p = LocalPalette.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val rows = (maxHeight / 100.dp).toInt().coerceAtLeast(1)
        val pages = apps.chunked(columns * rows).ifEmpty { listOf(emptyList<AppItem>()) }
        val state = rememberPagerState { pages.size }
        Column {
            HorizontalPager(state, Modifier.weight(1f)) { i ->
                Column(Modifier.fillMaxSize().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    pages[i].chunked(columns).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { AppCell(it, it.pkg in docked, a, Modifier.weight(1f)) }
                            repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            if (pages.size > 1) {
                Row(
                    Modifier.align(Alignment.CenterHorizontally).padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    repeat(pages.size) { n ->
                        val on = n == state.currentPage
                        Box(
                            Modifier.size(if (on) 8.dp else 6.dp).clip(CircleShape)
                                .background(p.text.copy(if (on) 0.8f else 0.3f))
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppCell(
    app: AppItem, docked: Boolean, a: Actions,
    modifier: Modifier = Modifier, showLabel: Boolean = true
) {
    var menu by remember { mutableStateOf(false) }
    Box(modifier) {
        Column(
            Modifier.fillMaxWidth()
                .combinedClickable(onClick = { a.open(app) }, onLongClick = { menu = true })
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(app.icon, app.label, Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)))
            if (showLabel) Text(
                app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(shadow = Shadow(Color.Black.copy(0.45f), blurRadius = 6f)),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text(if (docked) "Remove from Dock" else "Add to Dock") }, { menu = false; a.dock(app) })
            DropdownMenuItem({ Text("Hide in Grow OC") }, { menu = false; a.hide(app) })
            DropdownMenuItem({ Text("App info") }, { menu = false; a.info(app) })
        }
    }
}

@Composable
private fun Dock(apps: List<AppItem>, a: Actions) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).glass(RoundedCornerShape(32.dp)).padding(12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (apps.isEmpty())
            Text("Long-press an app, then Add to Dock", color = p.text.copy(0.5f), fontSize = 13.sp, modifier = Modifier.padding(8.dp))
        apps.forEach { AppCell(it, true, a, Modifier.weight(1f), showLabel = false) }
    }
}
