package com.growoc.launcher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.Settings
import android.text.format.DateFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import com.growoc.launcher.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

enum class IslandTab { QUICK, HOME }

@Composable
fun GrowIsland(tab: IslandTab?, onTab: (IslandTab) -> Unit, pr: Preferences, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    var last by remember { mutableStateOf(IslandTab.QUICK) }
    LaunchedEffect(tab) { if (tab != null) last = tab }

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IslandButton("QUICK", tab == IslandTab.QUICK) { onTab(IslandTab.QUICK) }
            Text(
                "Grow Island", Modifier.weight(1f), color = p.text.copy(0.45f),
                fontSize = 13.sp, textAlign = TextAlign.Center
            )
            IslandButton("HOME", tab == IslandTab.HOME) { onTab(IslandTab.HOME) }
        }
        AnimatedVisibility(tab != null, Modifier.padding(top = 8.dp)) {
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp), 0.82f).padding(20.dp)) {
                if ((tab ?: last) == IslandTab.QUICK) Quick() else HomePanel(pr)
            }
        }
    }
}

@Composable
private fun IslandButton(text: String, active: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier.clip(RoundedCornerShape(24.dp))
            .background(if (active) p.accent.copy(0.25f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 12.dp)
    ) {
        Text(text, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
    }
}

@Composable
private fun Quick() {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    // Updates once a minute, and only while Quick is open.
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L + 50)
        }
    }
    val bat by produceState(0 to false) {
        val rec = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { i.battery()?.let { value = it } }
        }
        ctx.registerReceiver(rec, IntentFilter(Intent.ACTION_BATTERY_CHANGED)).battery()?.let { value = it }
        awaitDispose { ctx.unregisterReceiver(rec) }
    }
    val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"

    Text(now.format(DateTimeFormatter.ofPattern(pattern)), color = p.text, fontSize = 64.sp, fontWeight = FontWeight.Light)
    Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = p.text.copy(0.65f), fontSize = 16.sp)
    Row(
        Modifier.fillMaxWidth().padding(top = 16.dp).glass(RoundedCornerShape(20.dp), 0.6f).padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Battery", color = p.text)
        Text("${bat.first}%" + if (bat.second) ", charging" else "", color = p.text.copy(0.7f))
    }
}

private fun Intent?.battery(): Pair<Int, Boolean>? {
    if (this == null) return null
    val level = getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val st = getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    if (level < 0) return null
    return (level * 100 / scale) to
        (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
}

@Composable
private fun HomePanel(pr: Preferences) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cur = pr[K.THEME] ?: "auto"
    val cols = pr[K.COLUMNS] ?: 4
    val hidden = pr[K.HIDDEN] ?: emptySet()

    Text("Grow Themes", color = p.text, fontWeight = FontWeight.SemiBold)
    LazyRow(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Chip("Auto", cur == "auto") { scope.launch { ctx.save(K.THEME, "auto") } } }
        items(Themes) { t -> Chip(t.name, cur == t.id) { scope.launch { ctx.save(K.THEME, t.id) } } }
    }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Grid columns", Modifier.weight(1f), color = p.text)
        Chip("−", false) { if (cols > 3) scope.launch { ctx.save(K.COLUMNS, cols - 1) } }
        Text("$cols", color = p.text, modifier = Modifier.padding(horizontal = 14.dp))
        Chip("+", false) { if (cols < 6) scope.launch { ctx.save(K.COLUMNS, cols + 1) } }
    }
    Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton("Set Grow OC as Home", true, {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }, Modifier.fillMaxWidth())
        GlassButton("Show setup guide again", true, {
            scope.launch { ctx.save(K.ONBOARDED, false) }
        }, Modifier.fillMaxWidth())
        if (hidden.isNotEmpty()) GlassButton("Show ${hidden.size} hidden apps", true, {
            scope.launch { ctx.save(K.HIDDEN, emptySet<String>()) }
        }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Text(
        text, color = p.text, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(16.dp))
            .background(if (on) p.accent.copy(0.3f) else p.text.copy(0.08f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}
