package com.growoc.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

private val Context.store by preferencesDataStore("grow_prefs")

/** Local settings keys. Everything lives on-device in DataStore. */
object K {
    val ONBOARDED = booleanPreferencesKey("onboarded")
    val THEME = stringPreferencesKey("theme")          // "auto" or a palette id
    val COLUMNS = intPreferencesKey("columns")
    val HIDDEN = stringSetPreferencesKey("hidden")     // hidden only inside Grow OC
    val DOCK = stringPreferencesKey("dock")            // comma-separated packages
}

val Context.prefs: Flow<Preferences> get() = store.data

suspend fun <T> Context.save(key: Preferences.Key<T>, v: T) {
    store.edit { it[key] = v }
}

data class AppItem(val pkg: String, val label: String, val intent: Intent, val icon: ImageBitmap)

suspend fun Context.loadApps(): List<AppItem> = withContext(Dispatchers.Default) {
    val pm = packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != packageName }
        .map {
            val ai = it.activityInfo
            AppItem(
                ai.packageName,
                it.loadLabel(pm).toString(),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(ai.packageName, ai.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            )
        }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}
