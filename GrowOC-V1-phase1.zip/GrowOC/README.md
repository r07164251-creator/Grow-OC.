# Grow OC — V1 BASIC UPDATE (phase 1 foundation)
Open this folder in Android Studio (Koala or newer, JDK 17), let Gradle sync, then
Build > Build APK(s). Min Android 10 (API 29). Package: com.growoc.launcher.

Included: first-start flow, Grow Home (pages, Dock, search, hide, app info),
Grow Island (QUICK: clock/date/battery; HOME: themes, columns, setup replay),
7 built-in themes + Auto. Not yet: GOOT, HOP, Spotify, wallpapers, widgets,
Studio, Control, notifications, drag-and-drop and folders.
